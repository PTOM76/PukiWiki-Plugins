function pukiwiki_pos()
{
	return;
}
function h_pukiwiki_make_copy_button(arg)
{
	document.write("");
}

function pukiwiki_initTexts()
{
	return;
}